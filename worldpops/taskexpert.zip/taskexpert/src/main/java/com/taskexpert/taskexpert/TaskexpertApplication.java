package com.taskexpert.taskexpert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskexpertApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskexpertApplication.class, args);
	}

}
